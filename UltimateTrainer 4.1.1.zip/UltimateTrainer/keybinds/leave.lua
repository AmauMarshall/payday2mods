if managers.system_menu:is_active() then
    managers.system_menu:force_close_all()
end

MenuCallbackHandler:_dialog_end_game_yes()