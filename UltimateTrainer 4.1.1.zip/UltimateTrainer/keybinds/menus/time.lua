if managers.system_menu:is_active() then
    do return end
end

UT.openMenu(UT.menus.time())